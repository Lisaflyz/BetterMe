package com.betterme.app.wxapi

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import com.betterme.app.R
import com.betterme.app.Session
import com.betterme.app.WechatManager
import com.tencent.mm.opensdk.modelbase.BaseReq
import com.tencent.mm.opensdk.modelbase.BaseResp
import com.tencent.mm.opensdk.modelmsg.SendAuth
import com.tencent.mm.opensdk.openapi.IWXAPIEventHandler

/**
 * 微信登录回调页（包名/类名固定规则：<applicationId>.wxapi.WXEntryActivity，不可改位置）。
 *
 * 流程：微信授权 → 微信拉起本 Activity → onResp 拿到授权 code
 *   → TODO(开发): 把 code 发给自己的后端 POST /api/v1/auth/wechat
 *     （后端用 AppID + AppSecret 换 access_token，再拿用户信息，返回你们自己的 token）
 *   → 当前为演示：本地标记“微信登录”，回到“我”页即显示已登录。
 */
class WXEntryActivity : Activity(), IWXAPIEventHandler {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WechatManager.handleIntent(this, intent, this)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        setIntent(intent)
        WechatManager.handleIntent(this, intent, this)
    }

    override fun onReq(req: BaseReq?) {
        // 微信登录场景一般无需处理
    }

    override fun onResp(resp: BaseResp?) {
        if (resp is SendAuth.Resp) {
            when (resp.errCode) {
                BaseResp.ErrCode.ERR_OK -> {
                    val code = resp.code
                    // TODO(开发): 调用后端 /api/v1/auth/wechat { "code": code }，
                    // 成功后保存后端 token/openid；这里先本地示例登录。
                    Session.demoLogin(this, "微信登录")
                    Toast.makeText(this, R.string.wx_success, Toast.LENGTH_SHORT).show()
                }
                BaseResp.ErrCode.ERR_USER_CANCEL ->
                    Toast.makeText(this, R.string.wx_canceled, Toast.LENGTH_SHORT).show()
                else ->
                    Toast.makeText(this, R.string.wx_denied, Toast.LENGTH_SHORT).show()
            }
        }
        finish()
    }
}
