package com.betterme.app

import android.content.Context
import android.graphics.Bitmap
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.util.Size
import android.widget.ImageView
import java.util.concurrent.Executors

/**
 * 简单缩略图加载器：后台线程解码 + 内存缓存。
 * 相册页与编辑页共用；正式项目建议换成 Coil / Glide。
 */
class MediaThumbLoader {

    private val cache = object : LinkedHashMap<String, Bitmap>(0, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, Bitmap>?): Boolean {
            return size > 256
        }
    }
    private val cacheLock = Any()
    private val executor = Executors.newFixedThreadPool(4)
    private val mainHandler = Handler(Looper.getMainLooper())

    fun load(item: MediaItem, imageView: ImageView) {
        val key = item.uri.toString()
        synchronized(cacheLock) {
            cache[key]?.let { bmp ->
                imageView.setImageBitmap(bmp)
                return
            }
        }
        imageView.tag = key
        imageView.setImageDrawable(null)
        executor.execute {
            val bmp = decode(item, imageView.context)
            if (bmp == null) return@execute
            synchronized(cacheLock) { cache[key] = bmp }
            mainHandler.post {
                if (imageView.tag == key) imageView.setImageBitmap(bmp)
            }
        }
    }

    private fun decode(item: MediaItem, context: Context): Bitmap? {
        return try {
            val cr = context.contentResolver
            if (Build.VERSION.SDK_INT >= 29) {
                cr.loadThumbnail(item.uri, Size(512, 512), null)
            } else {
                when (item.kind) {
                    MediaItem.Kind.PHOTO -> MediaStore.Images.Thumbnails.getThumbnail(
                        cr, item.id, MediaStore.Images.Thumbnails.MINI_KIND, null
                    )
                    MediaItem.Kind.VIDEO -> MediaStore.Video.Thumbnails.getThumbnail(
                        cr, item.id, MediaStore.Video.Thumbnails.MINI_KIND, null
                    )
                }
            }
        } catch (e: Exception) {
            null
        }
    }
}
