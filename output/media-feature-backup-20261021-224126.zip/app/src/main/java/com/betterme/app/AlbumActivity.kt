package com.betterme.app

import android.Manifest
import android.content.ContentUris
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.View
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.isVisible
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.betterme.app.databinding.ActivityAlbumBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * 相册多选页（参考 相册.jpg）。
 *
 * 支持：全部/照片/视频筛选、三列网格、多选序号角标、底部“下一步(N)”回传选中的 Uri。
 * TODO(开发)：返回结果后按业务需要进入“记录日常”的编辑/发布页。
 */
class AlbumActivity : AppCompatActivity() {

    companion object {
        const val MAX_SELECT = 9
        const val EXTRA_RESULT = "selected_uris"
        const val EXTRA_PRESELECT = "preselect_uris"
        const val EXTRA_RETURN_RESULT = "return_result"
        private const val SPAN = 3
    }

    private enum class Filter { ALL, PHOTO, VIDEO }

    private lateinit var binding: ActivityAlbumBinding
    private lateinit var adapter: AlbumAdapter

    private var filter = Filter.ALL
    private val allItems = mutableListOf<MediaItem>()
    private val selected = LinkedHashMap<Uri, MediaItem>()
    private var pendingPreselect: List<Uri> = emptyList()

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        if (result.containsValue(false)) {
            binding.loading.isVisible = false
            binding.tvEmpty.text = getString(R.string.album_permission_denied)
            binding.tvEmpty.isVisible = true
        } else {
            loadMedia()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAlbumBinding.inflate(layoutInflater)
        setContentView(binding.root)

        pendingPreselect = intent.getParcelableArrayListExtra<Uri>(EXTRA_PRESELECT).orEmpty()

        binding.btnBack.setOnClickListener { finish() }

        val spacingPx = (resources.displayMetrics.density * 2f).toInt()
        val screenW = resources.displayMetrics.widthPixels
        val cellSizePx = (screenW - spacingPx * SPAN) / SPAN

        adapter = AlbumAdapter(cellSizePx) { item -> toggleSelect(item) }
        adapter.selectionOrder = { item ->
            val index = selected.keys.indexOf(item.uri)
            if (index >= 0) index else -1
        }
        binding.recycler.layoutManager = GridLayoutManager(this, SPAN)
        binding.recycler.addItemDecoration(object : RecyclerView.ItemDecoration() {
            override fun getItemOffsets(
                outRect: android.graphics.Rect,
                view: View,
                parent: RecyclerView,
                state: RecyclerView.State
            ) {
                val p = spacingPx / 2
                outRect.set(p, 0, p, spacingPx)
            }
        })
        binding.recycler.adapter = adapter

        binding.chipAll.setOnClickListener { setFilter(Filter.ALL) }
        binding.chipPhoto.setOnClickListener { setFilter(Filter.PHOTO) }
        binding.chipVideo.setOnClickListener { setFilter(Filter.VIDEO) }

        binding.btnNext.setOnClickListener { confirmSelection() }
        updateNextButton()

        if (hasReadPermission()) {
            loadMedia()
        } else {
            permissionLauncher.launch(requiredPermissions())
        }
    }

    private fun requiredPermissions(): Array<String> =
        if (Build.VERSION.SDK_INT >= 33) {
            arrayOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO)
        } else {
            arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        }

    private fun hasReadPermission(): Boolean =
        requiredPermissions().all {
            ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED
        }

    private fun loadMedia() {
        binding.loading.isVisible = true
        binding.tvEmpty.isVisible = false
        // MediaStore 查询放到 IO 线程，避免主线程 ANR；页面销毁时协程自动取消
        lifecycleScope.launch {
            val combined = withContext(Dispatchers.IO) {
                (queryImages() + queryVideos())
                    .sortedWith(
                        compareByDescending<MediaItem> { it.dateAdded }
                            .thenByDescending { it.id }
                    )
            }
            allItems.clear()
            allItems.addAll(combined)
            binding.loading.isVisible = false
            applyPreselect()
            refreshGrid()
        }
    }

    /** 从编辑页“+”回来时，把已选的媒体在相册里置为选中状态。 */
    private fun applyPreselect() {
        selected.clear()
        for (uri in pendingPreselect) {
            if (selected.size >= MAX_SELECT) break
            allItems.find { it.uri == uri }?.let { selected[uri] = it }
        }
        updateNextButton()
    }

    private fun queryImages(): List<MediaItem> {
        val projection = arrayOf(
            MediaStore.Images.Media._ID,
            MediaStore.Images.Media.DATE_ADDED
        )
        val result = mutableListOf<MediaItem>()
        try {
            contentResolver.query(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                projection, null, null,
                "${MediaStore.Images.Media.DATE_ADDED} DESC"
            )?.use { c ->
                val idCol = c.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
                val dateCol = c.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_ADDED)
                while (c.moveToNext()) {
                    val id = c.getLong(idCol)
                    result.add(
                        MediaItem(
                            uri = ContentUris.withAppendedId(
                                MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id
                            ),
                            id = id,
                            kind = MediaItem.Kind.PHOTO,
                            dateAdded = c.getLong(dateCol)
                        )
                    )
                }
            }
        } catch (e: Exception) {
            // ignore: no media / permission lost
        }
        return result
    }

    private fun queryVideos(): List<MediaItem> {
        val projection = arrayOf(
            MediaStore.Video.Media._ID,
            MediaStore.Video.Media.DATE_ADDED,
            MediaStore.Video.Media.DURATION
        )
        val result = mutableListOf<MediaItem>()
        try {
            contentResolver.query(
                MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                projection, null, null,
                "${MediaStore.Video.Media.DATE_ADDED} DESC"
            )?.use { c ->
                val idCol = c.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
                val dateCol = c.getColumnIndexOrThrow(MediaStore.Video.Media.DATE_ADDED)
                val durCol = c.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
                while (c.moveToNext()) {
                    val id = c.getLong(idCol)
                    result.add(
                        MediaItem(
                            uri = ContentUris.withAppendedId(
                                MediaStore.Video.Media.EXTERNAL_CONTENT_URI, id
                            ),
                            id = id,
                            kind = MediaItem.Kind.VIDEO,
                            dateAdded = c.getLong(dateCol),
                            durationMs = c.getLong(durCol)
                        )
                    )
                }
            }
        } catch (e: Exception) {
            // ignore
        }
        return result
    }

    private fun setFilter(newFilter: Filter) {
        if (filter == newFilter) return
        filter = newFilter
        refreshGrid()
        binding.recycler.scrollToPosition(0)
        updateChipStyle()
    }

    private fun refreshGrid() {
        val visible = when (filter) {
            Filter.ALL -> allItems
            Filter.PHOTO -> allItems.filter { it.kind == MediaItem.Kind.PHOTO }
            Filter.VIDEO -> allItems.filter { it.kind == MediaItem.Kind.VIDEO }
        }
        adapter.submit(visible)
        binding.tvEmpty.isVisible = visible.isEmpty()
        if (visible.isEmpty()) {
            binding.tvEmpty.text = getString(R.string.album_empty)
        }
    }

    private fun updateChipStyle() {
        val selectedColor = ContextCompat.getColor(this, R.color.accent)
        val normalColor = ContextCompat.getColor(this, R.color.text_secondary)
        styleChip(
            binding.tvChipAll, binding.lineAll,
            filter == Filter.ALL, selectedColor, normalColor
        )
        styleChip(
            binding.tvChipPhoto, binding.linePhoto,
            filter == Filter.PHOTO, selectedColor, normalColor
        )
        styleChip(
            binding.tvChipVideo, binding.lineVideo,
            filter == Filter.VIDEO, selectedColor, normalColor
        )
    }

    private fun styleChip(
        text: android.widget.TextView,
        line: View,
        selected: Boolean,
        selectedColor: Int,
        normalColor: Int
    ) {
        text.setTextColor(if (selected) selectedColor else normalColor)
        text.typeface = if (selected) {
            android.graphics.Typeface.DEFAULT_BOLD
        } else {
            android.graphics.Typeface.DEFAULT
        }
        line.setBackgroundColor(if (selected) selectedColor else Color.TRANSPARENT)
    }

    private fun toggleSelect(item: MediaItem) {
        if (selected.containsKey(item.uri)) {
            selected.remove(item.uri)
        } else {
            if (selected.size >= MAX_SELECT) {
                android.widget.Toast.makeText(
                    this, R.string.album_too_many, android.widget.Toast.LENGTH_SHORT
                ).show()
                return
            }
            selected[item.uri] = item
        }
        adapter.notifyDataSetChanged()
        updateNextButton()
    }

    private fun updateNextButton() {
        val count = selected.size
        binding.btnNext.text = if (count == 0) {
            getString(R.string.album_next_0)
        } else {
            getString(R.string.album_next_n, count)
        }
        val enabled = count > 0
        binding.btnNext.isEnabled = enabled
        binding.btnNext.isClickable = enabled
        binding.btnNext.background = ContextCompat.getDrawable(
            this, if (enabled) R.drawable.bg_pill_primary else R.drawable.bg_pill_disabled
        )
    }

    private fun confirmSelection() {
        if (selected.isEmpty()) return
        val uris = ArrayList(selected.keys)
        val returnResult = intent.getBooleanExtra(EXTRA_RETURN_RESULT, false)
        if (returnResult) {
            // 编辑页“+”继续添加：把最终选择回传
            val data = Intent().putParcelableArrayListExtra(EXTRA_RESULT, uris)
            setResult(RESULT_OK, data)
        } else {
            // 弹窗进入：跳转“记录日常”编辑页，把选中的图片/视频带过去
            val intent = Intent(this, EditActivity::class.java)
                .putParcelableArrayListExtra(EditActivity.EXTRA_MEDIA_URIS, uris)
            startActivity(intent)
        }
        finish()
    }
}
