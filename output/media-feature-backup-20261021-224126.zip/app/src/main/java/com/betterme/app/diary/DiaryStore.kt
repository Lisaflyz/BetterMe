package com.betterme.app.diary

import android.content.Context
import android.util.AtomicFile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

data class DiaryEntry(
    val id: String = UUID.randomUUID().toString(),
    val date: String,
    val title: String = "",
    val content: String = "",
    val weather: String = "",
    val mood: String = "",
    val activity: String = "",
    val photos: List<String> = emptyList(),
    val fontSize: Int = 16,
    val paper: Int = 0,
    val updatedAt: Long = 0L
) {
    fun toJson() = JSONObject().apply {
        put("id", id)
        put("date", date)
        put("title", title)
        put("content", content)
        put("weather", weather)
        put("mood", mood)
        put("activity", activity)
        put("photos", JSONArray(photos))
        put("fontSize", fontSize)
        put("paper", paper)
        put("updatedAt", updatedAt)
    }

    companion object {
        fun fromJson(json: JSONObject) = DiaryEntry(
            id = json.getString("id"),
            date = json.getString("date"),
            title = json.optString("title"),
            content = json.optString("content"),
            weather = json.optString("weather"),
            mood = json.optString("mood"),
            activity = json.optString("activity"),
            photos = json.optJSONArray("photos")?.let { array ->
                (0 until array.length()).map { array.getString(it) }
            }.orEmpty().take(9),
            fontSize = json.optInt("fontSize", 16).coerceIn(14, 20),
            paper = json.optInt("paper", 0).coerceIn(0, 2),
            updatedAt = json.optLong("updatedAt")
        )
    }
}

/** 日记保存在 App 私有目录；原子写入，写入失败时保留上一版本。 */
class DiaryStore(context: Context) {
    private val directory = File(context.applicationContext.filesDir, "diary_entries")

    suspend fun save(entry: DiaryEntry) = withContext(Dispatchers.IO) {
        require(UUID.fromString(entry.id).toString() == entry.id)
        check(directory.isDirectory || directory.mkdirs())
        val file = AtomicFile(File(directory, "${entry.id}.json"))
        val stream = file.startWrite()
        try {
            stream.write(entry.toJson().toString().toByteArray(Charsets.UTF_8))
            file.finishWrite(stream)
        } catch (error: Exception) {
            file.failWrite(stream)
            throw error
        }
    }

    suspend fun list(): List<DiaryEntry> = withContext(Dispatchers.IO) {
        directory.listFiles().orEmpty().filter { it.extension == "json" }
            .map { file ->
                val bytes = AtomicFile(file).readFully()
                DiaryEntry.fromJson(JSONObject(bytes.toString(Charsets.UTF_8)))
            }
            .sortedByDescending { it.updatedAt }
    }
}
