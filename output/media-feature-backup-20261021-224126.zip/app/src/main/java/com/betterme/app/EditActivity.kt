package com.betterme.app

import android.content.ContentUris
import android.content.Intent
import android.graphics.Rect
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.isVisible
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.betterme.app.databinding.ActivityEditBinding
import com.betterme.app.databinding.ItemEditMediaAddBinding
import com.betterme.app.databinding.ItemEditMediaBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * “记录日常”编辑页（参考 编辑页.jpg，小红书发布页风格）。
 *
 * - 从相册页接收选中的图片/视频；未满 9 张时，媒体列表末尾显示“+”，可回到相册继续添加；
 * - 缩略图圆角 6dp，格子间距 5dp；
 * - 标题/正文获得焦点弹出键盘时，隐藏底部“公开可见/发布”栏，避免被顶到键盘上方；
 * - 发布/存草稿目前是示例，TODO 接入后端或本地存储。
 */
class EditActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_MEDIA_URIS = "media_uris"
        private const val TYPE_MEDIA = 0
        private const val TYPE_ADD = 1
    }

    private lateinit var binding: ActivityEditBinding
    private lateinit var adapter: EditMediaAdapter

    private val mediaItems = mutableListOf<MediaItem>()

    private val albumLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) {
            val uris: ArrayList<Uri>? = result.data
                ?.getParcelableArrayListExtra(AlbumActivity.EXTRA_RESULT)
            if (!uris.isNullOrEmpty()) {
                // 重新解析（含新加的照片/视频），替换当前媒体列表
                lifecycleScope.launch {
                    val items = withContext(Dispatchers.IO) {
                        uris.mapNotNull { resolveMedia(it) }
                    }
                    mediaItems.clear()
                    mediaItems.addAll(items)
                    renderMedia()
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityEditBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val density = resources.displayMetrics.density
        val cellPx = (density * 100f).toInt()
        val spacingPx = (density * 5f).toInt()
        adapter = EditMediaAdapter(cellPx, spacingPx) { openAlbumForMore() }
        binding.rvMedia.layoutManager =
            LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        binding.rvMedia.adapter = adapter

        binding.btnBack.setOnClickListener { finish() }
        binding.btnDraft.setOnClickListener {
            Toast.makeText(this, R.string.edit_draft_todo, Toast.LENGTH_SHORT).show()
        }
        binding.rowTopic.setOnClickListener {
            Toast.makeText(this, R.string.edit_topic_todo, Toast.LENGTH_SHORT).show()
        }
        binding.rowLocation.setOnClickListener {
            Toast.makeText(this, R.string.edit_location_todo, Toast.LENGTH_SHORT).show()
        }
        binding.rowVisibility.setOnClickListener {
            Toast.makeText(this, R.string.edit_visibility_todo, Toast.LENGTH_SHORT).show()
        }
        binding.tvVisibilityBottom.setOnClickListener {
            Toast.makeText(this, R.string.edit_visibility_todo, Toast.LENGTH_SHORT).show()
        }
        binding.btnPublish.setOnClickListener { publish() }

        // 键盘弹出时隐藏底部栏（避免“公开可见/发布”被顶到键盘上方）
        binding.root.viewTreeObserver.addOnGlobalLayoutListener {
            val rect = Rect()
            binding.root.getWindowVisibleDisplayFrame(rect)
            val screenHeight = binding.root.rootView.height
            val diff = screenHeight - (rect.bottom - rect.top)
            val imeVisible = diff > (density * 160f).toInt()
            binding.bottomBar.isVisible = !imeVisible
        }

        // 接收相册页带过来的媒体；getType / 时长查询放 IO 线程
        val uris: ArrayList<Uri>? = intent.getParcelableArrayListExtra(EXTRA_MEDIA_URIS)
        lifecycleScope.launch {
            val items = withContext(Dispatchers.IO) {
                uris.orEmpty().mapNotNull { resolveMedia(it) }
            }
            if (items.isEmpty()) {
                Toast.makeText(this@EditActivity, R.string.album_empty, Toast.LENGTH_SHORT).show()
                finish()
                return@launch
            }
            mediaItems.addAll(items)
            renderMedia()
        }
    }

    private fun renderMedia() {
        val showPlus = mediaItems.size < AlbumActivity.MAX_SELECT
        adapter.submit(mediaItems.toList(), showPlus)
    }

    private fun openAlbumForMore() {
        if (mediaItems.size >= AlbumActivity.MAX_SELECT) return
        val intent = Intent(this, AlbumActivity::class.java).apply {
            putExtra(AlbumActivity.EXTRA_RETURN_RESULT, true)
            putParcelableArrayListExtra(
                AlbumActivity.EXTRA_PRESELECT,
                ArrayList(mediaItems.map { it.uri })
            )
        }
        albumLauncher.launch(intent)
    }

    /** 把 Uri 解析成 MediaItem（照片/视频 + 时长）。 */
    private fun resolveMedia(uri: Uri): MediaItem? {
        return try {
            val type = contentResolver.getType(uri) ?: return null
            val id = ContentUris.parseId(uri)
            if (type.startsWith("video")) {
                var duration = 0L
                contentResolver.query(
                    uri, arrayOf(MediaStore.Video.Media.DURATION), null, null, null
                )?.use { c ->
                    if (c.moveToFirst()) duration = c.getLong(0)
                }
                MediaItem(uri, id, MediaItem.Kind.VIDEO, 0L, duration)
            } else if (type.startsWith("image")) {
                MediaItem(uri, id, MediaItem.Kind.PHOTO, 0L)
            } else {
                null
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun publish() {
        // TODO(开发)：这里把标题/正文/媒体真正保存或上传。
        binding.etTitle.text?.toString().orEmpty().trim()
        binding.etContent.text?.toString().orEmpty().trim()
        Toast.makeText(
            this,
            getString(R.string.edit_publish_done, mediaItems.size),
            Toast.LENGTH_SHORT
        ).show()
        finish()
    }

    /** 已选媒体横向预览 + 末尾“+”添加格。 */
    private class EditMediaAdapter(
        private val cellSizePx: Int,
        private val spacingPx: Int,
        private val onAddMoreClick: () -> Unit
    ) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

        private val items = mutableListOf<MediaItem>()
        private var showPlus = false
        private val loader = MediaThumbLoader()

        fun submit(list: List<MediaItem>, plus: Boolean) {
            items.clear()
            items.addAll(list)
            showPlus = plus
            notifyDataSetChanged()
        }

        override fun getItemCount(): Int = items.size + if (showPlus) 1 else 0

        override fun getItemViewType(position: Int): Int =
            if (position < items.size) TYPE_MEDIA else TYPE_ADD

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
            return if (viewType == TYPE_ADD) {
                val binding = ItemEditMediaAddBinding.inflate(
                    LayoutInflater.from(parent.context), parent, false
                )
                squareParams(binding.addRoot)
                binding.addRoot.setOnClickListener { onAddMoreClick() }
                AddVH(binding)
            } else {
                val binding = ItemEditMediaBinding.inflate(
                    LayoutInflater.from(parent.context), parent, false
                )
                squareParams(binding.mediaRoot)
                MediaVH(binding)
            }
        }

        override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
            if (holder is MediaVH) {
                val item = items[position]
                loader.load(item, holder.binding.ivThumb)
                if (item.kind == MediaItem.Kind.VIDEO) {
                    holder.binding.tvVideo.visibility = android.view.View.VISIBLE
                    holder.binding.tvVideo.text = formatDuration(item.durationMs)
                } else {
                    holder.binding.tvVideo.visibility = android.view.View.GONE
                }
            }
        }

        private fun squareParams(view: android.view.View) {
            view.layoutParams = FrameLayout.LayoutParams(cellSizePx, cellSizePx).apply {
                marginEnd = spacingPx
                gravity = Gravity.CENTER_VERTICAL
            }
        }

        private fun formatDuration(ms: Long): String {
            val totalSec = ms / 1000
            val h = totalSec / 3600
            val m = (totalSec % 3600) / 60
            val s = totalSec % 60
            return if (h > 0) {
                String.format("%d:%02d:%02d", h, m, s)
            } else {
                String.format("%02d:%02d", m, s)
            }
        }

        class MediaVH(val binding: ItemEditMediaBinding) :
            RecyclerView.ViewHolder(binding.root)

        class AddVH(val binding: ItemEditMediaAddBinding) :
            RecyclerView.ViewHolder(binding.root)
    }
}
