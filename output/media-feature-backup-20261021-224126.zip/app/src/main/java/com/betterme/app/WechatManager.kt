package com.betterme.app

import android.content.Context
import android.content.Intent
import android.widget.Toast
import com.tencent.mm.opensdk.modelmsg.SendAuth
import com.tencent.mm.opensdk.openapi.IWXAPI
import com.tencent.mm.opensdk.openapi.WXAPIFactory

/**
 * 微信登录封装：注册 AppID、拉起微信授权。
 *
 * 前置条件（在微信开放平台 open.weixin.qq.com 完成）：
 * 1. 创建“移动应用”，包名填 com.betterme.app，应用签名填 debug/release 证书的 MD5；
 * 2. 审核通过后把 AppID 填到 res/values/strings.xml 的 wechat_app_id；
 * 3. 回调由 com.betterme.app.wxapi.WXEntryActivity 接收（见 AndroidManifest 与 wxapi 包）。
 */
object WechatManager {

    private const val SCOPE = "snsapi_userinfo"
    private const val STATE = "betterme_wechat_login"

    private var api: IWXAPI? = null

    @Synchronized
    private fun api(context: Context): IWXAPI {
        api?.let { return it }
        val appId = context.getString(R.string.wechat_app_id)
        val created = WXAPIFactory.createWXAPI(context, appId, true)
        created.registerApp(appId)
        api = created
        return created
    }

    fun isInstalled(context: Context): Boolean = api(context).isWXAppInstalled

    /** 拉起微信授权登录。结果在 WXEntryActivity.onResp 里收到。 */
    fun login(context: Context) {
        val wx = api(context)
        if (!wx.isWXAppInstalled) {
            Toast.makeText(context, R.string.wx_not_installed, Toast.LENGTH_SHORT).show()
            return
        }
        val req = SendAuth.Req()
        req.scope = SCOPE
        req.state = STATE
        if (!wx.sendReq(req)) {
            Toast.makeText(context, R.string.wx_send_failed, Toast.LENGTH_SHORT).show()
        }
    }

    /** 供 WXEntryActivity 在 onCreate/onNewIntent 里把 Intent 交给 SDK。 */
    fun handleIntent(context: Context, intent: Intent?, handler: com.tencent.mm.opensdk.openapi.IWXAPIEventHandler) {
        api(context).handleIntent(intent, handler)
    }
}
