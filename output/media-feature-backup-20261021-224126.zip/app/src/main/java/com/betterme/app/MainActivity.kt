package com.betterme.app

import android.graphics.PorterDuff
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import com.betterme.app.databinding.ActivityMainBinding
import com.betterme.app.ui.AddEntryDialogFragment
import com.betterme.app.ui.DailyFragment
import com.betterme.app.ui.GrowthFragment
import com.betterme.app.ui.ProfileFragment
import com.betterme.app.ui.SkillsFragment

/**
 * Better Me 主界面。
 *
 * 底部 Tab：每日 | 成长 | 加号 | 技能 | 我。
 * 点击中间的 + 弹出添加弹层（参考 弹窗.jpg）；
 * 「我」未登录时展示登录页（参考 登录.jpg / 手机登录.jpg）。
 */
class MainActivity : AppCompatActivity() {

    companion object {
        private const val TAB_DAILY = 0
        private const val TAB_GROWTH = 1
        private const val TAB_ME = 2
        private const val TAB_SKILLS = 3
        private const val TAG_ADD_ENTRY = "add_entry"
    }

    private lateinit var binding: ActivityMainBinding

    private val dailyFragment by lazy {
        supportFragmentManager.findFragmentByTag("daily") as? DailyFragment ?: DailyFragment()
    }
    private val growthFragment by lazy {
        supportFragmentManager.findFragmentByTag("growth") as? GrowthFragment ?: GrowthFragment()
    }
    private val skillsFragment by lazy {
        supportFragmentManager.findFragmentByTag("skills") as? SkillsFragment ?: SkillsFragment()
    }
    private val profileFragment by lazy {
        supportFragmentManager.findFragmentByTag("me") as? ProfileFragment ?: ProfileFragment()
    }
    private var currentFragment: Fragment? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.tabDaily.setOnClickListener { switchTab(TAB_DAILY) }
        binding.tabGrowth.setOnClickListener { switchTab(TAB_GROWTH) }
        binding.tabSkills.setOnClickListener { switchTab(TAB_SKILLS) }
        binding.tabMe.setOnClickListener { switchTab(TAB_ME) }
        binding.plusButton.setOnClickListener {
            AddEntryDialogFragment().show(supportFragmentManager, TAG_ADD_ENTRY)
        }

        currentFragment = supportFragmentManager.findFragmentById(R.id.fragmentContainer)
        if (currentFragment == null) {
            switchTab(TAB_DAILY)
        } else {
            updateTabStyle(when (currentFragment) {
                is GrowthFragment -> TAB_GROWTH
                is SkillsFragment -> TAB_SKILLS
                is ProfileFragment -> TAB_ME
                else -> TAB_DAILY
            })
        }
    }

    private fun switchTab(tab: Int) {
        val target: Fragment = when (tab) {
            TAB_ME -> profileFragment
            TAB_GROWTH -> growthFragment
            TAB_SKILLS -> skillsFragment
            else -> dailyFragment
        }
        val tag = when (tab) {
            TAB_ME -> "me"
            TAB_GROWTH -> "growth"
            TAB_SKILLS -> "skills"
            else -> "daily"
        }
        updateTabStyle(tab)
        if (currentFragment === target) return
        currentFragment = target

        supportFragmentManager.beginTransaction()
            .setCustomAnimations(android.R.anim.fade_in, android.R.anim.fade_out)
            .replace(R.id.fragmentContainer, target, tag)
            .commit()
    }

    private fun updateTabStyle(selectedTab: Int) {
        val selectedColor = ContextCompat.getColor(this, R.color.brand_gold)
        val normalColor = ContextCompat.getColor(this, R.color.nav_inactive)

        styleTab(
            binding.iconDaily, binding.labelDaily,
            selected = selectedTab == TAB_DAILY,
            selectedColor = selectedColor,
            normalColor = normalColor
        )
        styleTab(
            binding.iconGrowth, binding.labelGrowth,
            selected = selectedTab == TAB_GROWTH,
            selectedColor = selectedColor,
            normalColor = normalColor
        )
        styleTab(
            binding.iconSkills, binding.labelSkills,
            selected = selectedTab == TAB_SKILLS,
            selectedColor = selectedColor,
            normalColor = normalColor
        )
        styleTab(
            binding.iconMe, binding.labelMe,
            selected = selectedTab == TAB_ME,
            selectedColor = selectedColor,
            normalColor = normalColor
        )
    }

    private fun styleTab(
        icon: ImageView,
        label: TextView,
        selected: Boolean,
        selectedColor: Int,
        normalColor: Int
    ) {
        val color = if (selected) selectedColor else normalColor
        icon.setColorFilter(color, PorterDuff.Mode.SRC_IN)
        label.setTextColor(color)
        label.typeface = if (selected) {
            android.graphics.Typeface.DEFAULT_BOLD
        } else {
            android.graphics.Typeface.DEFAULT
        }
    }
}
