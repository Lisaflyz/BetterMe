package com.betterme.app

import android.app.DatePickerDialog
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.speech.RecognizerIntent
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.addCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.TooltipCompat
import androidx.core.content.ContextCompat
import androidx.core.view.isVisible
import androidx.core.widget.doAfterTextChanged
import androidx.lifecycle.lifecycleScope
import com.betterme.app.databinding.ActivityDiaryBinding
import com.betterme.app.diary.DiaryEntry
import com.betterme.app.diary.DiaryStore
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** “日常.jpg”对应的日记页。照片可选，文字可独立保存。 */
class DiaryActivity : AppCompatActivity() {
    private lateinit var binding: ActivityDiaryBinding
    private lateinit var entry: DiaryEntry
    private lateinit var store: DiaryStore
    private var initialFingerprint = ""
    private var saving = false
    private var photoJob: Job? = null

    private val photoPicker = registerForActivityResult(
        ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        val available = 9 - entry.photos.size
        val added = uris.distinct().filter { it.toString() !in entry.photos }
        if (added.size > available) toast(R.string.diary_photo_limit)
        val accepted = added.take(available).mapNotNull { uri ->
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                uri.toString()
            } catch (_: SecurityException) {
                toast(R.string.diary_photo_error)
                null
            }
        }
        entry = entry.copy(photos = entry.photos + accepted)
        renderPhotos()
    }

    private val voiceInput = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) {
            result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                ?.firstOrNull()?.let(::insertText)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDiaryBinding.inflate(layoutInflater)
        setContentView(binding.root)
        store = DiaryStore(this)

        val restored = savedInstanceState?.getString("entry")?.let {
            DiaryEntry.fromJson(JSONObject(it))
        }
        showEntry(restored ?: DiaryEntry(date = today()))
        initialFingerprint = savedInstanceState?.getString("initialFingerprint") ?: fingerprint()

        binding.etContent.doAfterTextChanged { updateWordCount() }
        binding.btnBack.setOnClickListener { requestExit() }
        binding.btnDate.setOnClickListener { pickDate() }
        binding.btnSave.setOnClickListener { save() }
        binding.btnLibrary.setOnClickListener { showLibrary() }
        binding.btnAddPhoto.setOnClickListener {
            if (entry.photos.size < 9) photoPicker.launch(arrayOf("image/*"))
            else toast(R.string.diary_photo_limit)
        }
        binding.btnWeather.setOnClickListener {
            chooseTag(R.string.diary_weather, R.array.diary_weather_options, entry.weather) {
                entry = entry.copy(weather = it)
            }
        }
        binding.btnMood.setOnClickListener {
            chooseTag(R.string.diary_mood, R.array.diary_mood_options, entry.mood) {
                entry = entry.copy(mood = it)
            }
        }
        binding.btnActivity.setOnClickListener {
            chooseTag(R.string.diary_activity, R.array.diary_activity_options, entry.activity) {
                entry = entry.copy(activity = it)
            }
        }
        binding.btnTime.setOnClickListener {
            insertText(SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date()) + " ")
        }
        binding.btnPaper.setOnClickListener {
            MaterialAlertDialogBuilder(this).setTitle(R.string.diary_paper)
                .setSingleChoiceItems(R.array.diary_paper_options, entry.paper) { dialog, which ->
                    entry = entry.copy(paper = which)
                    renderFormatting()
                    dialog.dismiss()
                }.setNegativeButton(R.string.diary_cancel, null).show()
        }
        binding.btnFont.setOnClickListener {
            val sizes = listOf(14, 16, 18, 20)
            MaterialAlertDialogBuilder(this).setTitle(R.string.diary_font)
                .setSingleChoiceItems(R.array.diary_font_options, sizes.indexOf(entry.fontSize)) { dialog, which ->
                    entry = entry.copy(fontSize = sizes[which])
                    renderFormatting()
                    dialog.dismiss()
                }.setNegativeButton(R.string.diary_cancel, null).show()
        }
        binding.btnEmoji.setOnClickListener {
            val options = resources.getStringArray(R.array.diary_emoji_options)
            MaterialAlertDialogBuilder(this).setTitle(R.string.diary_emoji)
                .setItems(options) { _, which -> insertText(options[which]) }.show()
        }
        binding.btnChecklist.setOnClickListener {
            val cursor = binding.etContent.selectionStart.coerceAtLeast(0)
            val prefix = if (cursor > 0 && binding.etContent.text[cursor - 1] != '\n') "\n" else ""
            insertText(prefix + "☐ ")
        }
        binding.btnVoice.setOnClickListener {
            try {
                voiceInput.launch(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag())
                    putExtra(RecognizerIntent.EXTRA_PROMPT, getString(R.string.diary_voice))
                })
            } catch (_: ActivityNotFoundException) {
                toast(R.string.diary_voice_unavailable)
            }
        }
        listOf(binding.btnLibrary, binding.btnSave, binding.btnTime, binding.btnPaper,
            binding.btnEmoji, binding.btnFont, binding.btnChecklist, binding.btnVoice).forEach {
            TooltipCompat.setTooltipText(it, it.contentDescription)
        }
        onBackPressedDispatcher.addCallback(this) { requestExit() }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        // 限制正文 20000 字、照片 9 张；仅保存 URI，不把位图写入 Bundle。
        outState.putString("entry", snapshot().toJson().toString())
        outState.putString("initialFingerprint", initialFingerprint)
        super.onSaveInstanceState(outState)
    }

    private fun snapshot() = entry.copy(
        title = binding.etTitle.text.toString(),
        content = binding.etContent.text.toString()
    )

    private fun fingerprint(): String = MessageDigest.getInstance("SHA-256")
        .digest(snapshot().toJson().toString().toByteArray(Charsets.UTF_8))
        .joinToString("") { "%02x".format(it) }

    private fun showEntry(value: DiaryEntry) {
        entry = value
        binding.etTitle.setText(value.title)
        binding.etContent.setText(value.content)
        renderDate()
        renderTags()
        renderFormatting()
        renderPhotos()
        updateWordCount()
        initialFingerprint = fingerprint()
    }

    private fun renderDate() {
        val (year, month, day) = entry.date.split('-').map(String::toInt)
        binding.tvDay.text = day.toString()
        binding.tvMonth.text = getString(R.string.diary_month, year, month)
        binding.btnDate.contentDescription = getString(R.string.diary_date) + "，" + entry.date
    }

    private fun pickDate() {
        val (year, month, day) = entry.date.split('-').map(String::toInt)
        DatePickerDialog(this, { _, y, m, d ->
            entry = entry.copy(date = String.format(Locale.ROOT, "%04d-%02d-%02d", y, m + 1, d))
            renderDate()
        }, year, month - 1, day).show()
    }

    private fun chooseTag(title: Int, optionsId: Int, current: String, update: (String) -> Unit) {
        val options = resources.getStringArray(optionsId)
        MaterialAlertDialogBuilder(this).setTitle(title)
            .setSingleChoiceItems(options, options.indexOf(current)) { dialog, which ->
                update(options[which])
                renderTags()
                dialog.dismiss()
            }.setNeutralButton(R.string.diary_clear) { _, _ ->
                update("")
                renderTags()
            }.setNegativeButton(R.string.diary_cancel, null).show()
    }

    private fun renderTags() {
        fun render(view: TextView, label: Int, value: String) {
            view.text = value.ifEmpty { getString(label) }
            view.isSelected = value.isNotEmpty()
            view.contentDescription = getString(label) + "，" + view.text
        }
        render(binding.btnWeather, R.string.diary_weather, entry.weather)
        render(binding.btnMood, R.string.diary_mood, entry.mood)
        render(binding.btnActivity, R.string.diary_activity, entry.activity)
    }

    private fun renderFormatting() {
        val color = listOf(R.color.surface, R.color.accent_light, R.color.gold_light)[entry.paper]
        binding.editorScroll.setBackgroundColor(ContextCompat.getColor(this, color))
        binding.etContent.textSize = entry.fontSize.toFloat()
    }

    private fun updateWordCount() {
        val text = binding.etContent.text.toString().filterNot(Char::isWhitespace)
        val count = Character.codePointCount(text, 0, text.length)
        binding.tvWordCount.text = getString(R.string.diary_word_count, count)
    }

    private fun insertText(text: String) {
        val edit = binding.etContent
        val start = edit.selectionStart.coerceAtLeast(0)
        val end = edit.selectionEnd.coerceAtLeast(start)
        if (edit.length() - (end - start) + text.length > 20000) {
            toast(R.string.diary_format_limit)
            return
        }
        edit.text.replace(start, end, text)
        edit.requestFocus()
        edit.setSelection(start + text.length)
    }

    private fun renderPhotos() {
        photoJob?.cancel()
        binding.photoStrip.removeAllViews()
        binding.btnAddPhoto.isVisible = entry.photos.size < 9
        val views = entry.photos.mapIndexed { index, uri ->
            val image = ImageView(this).apply {
                layoutParams = LinearLayout.LayoutParams(dp(80), dp(80)).apply { marginEnd = dp(8) }
                scaleType = ImageView.ScaleType.CENTER_CROP
                setBackgroundResource(R.drawable.bg_image_placeholder)
                clipToOutline = true
                setImageResource(R.drawable.ic_diary_camera)
                contentDescription = getString(R.string.diary_photo_description, index + 1)
                setOnClickListener {
                    MaterialAlertDialogBuilder(this@DiaryActivity).setTitle(R.string.diary_remove_photo)
                        .setPositiveButton(R.string.diary_remove_photo) { _, _ ->
                            entry = entry.copy(photos = entry.photos.filterNot { it == uri })
                            renderPhotos()
                        }.setNegativeButton(R.string.diary_cancel, null).show()
                }
            }
            binding.photoStrip.addView(image)
            uri to image
        }
        photoJob = lifecycleScope.launch {
            for ((uri, image) in views) {
                val bitmap = withContext(Dispatchers.IO) { thumbnail(Uri.parse(uri)) }
                if (bitmap != null) image.setImageBitmap(bitmap)
            }
        }
    }

    private fun thumbnail(uri: Uri): Bitmap? = try {
        val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, options) }
        options.inSampleSize = 1
        while (options.outWidth / options.inSampleSize > 512 || options.outHeight / options.inSampleSize > 512) {
            options.inSampleSize *= 2
        }
        options.inJustDecodeBounds = false
        contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, options) }
    } catch (_: Exception) {
        null
    }

    private fun save() {
        if (saving) return
        val value = snapshot().copy(updatedAt = System.currentTimeMillis())
        if (value.title.isBlank() && value.content.isBlank() && value.photos.isEmpty()) {
            toast(R.string.diary_empty)
            return
        }
        saving = true
        enableTree(binding.root, false)
        lifecycleScope.launch {
            try {
                store.save(value)
                toast(R.string.diary_saved)
                finish()
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (_: Exception) {
                toast(R.string.diary_save_error)
            } finally {
                saving = false
                enableTree(binding.root, true)
            }
        }
    }

    private fun showLibrary() {
        binding.btnLibrary.isEnabled = false
        lifecycleScope.launch {
            try {
                val entries = store.list()
                if (entries.isEmpty()) {
                    toast(R.string.diary_library_empty)
                    return@launch
                }
                val labels = entries.map {
                    "${it.date}  ${it.title.ifBlank { getString(R.string.diary_untitled) }}"
                }.toTypedArray()
                MaterialAlertDialogBuilder(this@DiaryActivity).setTitle(R.string.diary_library)
                    .setItems(labels) { _, which ->
                        val selected = entries[which]
                        if (fingerprint() == initialFingerprint) showEntry(selected)
                        else MaterialAlertDialogBuilder(this@DiaryActivity)
                            .setTitle(R.string.diary_unsaved).setMessage(R.string.diary_replace_message)
                            .setPositiveButton(R.string.diary_open) { _, _ -> showEntry(selected) }
                            .setNegativeButton(R.string.diary_continue, null).show()
                    }.setNegativeButton(R.string.diary_cancel, null).show()
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (_: Exception) {
                toast(R.string.diary_read_error)
            } finally {
                binding.btnLibrary.isEnabled = true
            }
        }
    }

    private fun requestExit() {
        if (saving) return
        if (fingerprint() == initialFingerprint) {
            finish()
            return
        }
        MaterialAlertDialogBuilder(this).setTitle(R.string.diary_unsaved)
            .setMessage(R.string.diary_unsaved_message)
            .setPositiveButton(R.string.diary_save_exit) { _, _ -> save() }
            .setNegativeButton(R.string.diary_discard) { _, _ -> finish() }
            .setNeutralButton(R.string.diary_continue, null).show()
    }

    private fun enableTree(view: View, enabled: Boolean) {
        view.isEnabled = enabled
        if (view is ViewGroup) for (i in 0 until view.childCount) enableTree(view.getChildAt(i), enabled)
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    private fun toast(message: Int) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    private fun today(): String = Calendar.getInstance().run {
        String.format(Locale.ROOT, "%04d-%02d-%02d", get(Calendar.YEAR), get(Calendar.MONTH) + 1, get(Calendar.DAY_OF_MONTH))
    }
}
