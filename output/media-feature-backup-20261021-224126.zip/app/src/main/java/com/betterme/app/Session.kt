package com.betterme.app

import android.content.Context

/**
 * 本地登录态。
 *
 * TODO(开发)：接入真实后端后，统一用 loginWithToken() 保存服务端下发的 token；
 * 后续请求带 Authorization: Bearer <token>。
 */
object Session {

    private const val PREFS = "betterme_prefs"
    private const val KEY_LOGGED_IN = "logged_in"
    private const val KEY_PHONE = "phone"
    private const val KEY_TOKEN = "token"
    private const val KEY_USER_ID = "user_id"

    fun isLoggedIn(context: Context): Boolean =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getBoolean(KEY_LOGGED_IN, false)

    fun getPhone(context: Context): String =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_PHONE, "").orEmpty()

    fun getToken(context: Context): String =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_TOKEN, "").orEmpty()

    /** 真实后端登录成功后的写入方式。 */
    fun loginWithToken(context: Context, phone: String, token: String, userId: Long) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putBoolean(KEY_LOGGED_IN, true)
            .putString(KEY_PHONE, phone)
            .putString(KEY_TOKEN, token)
            .putLong(KEY_USER_ID, userId)
            .apply()
    }

    /** 微信/手机号登录的“本地示例”登录（后端未就绪时演示用）。 */
    fun demoLogin(context: Context, displayPhone: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putBoolean(KEY_LOGGED_IN, true)
            .putString(KEY_PHONE, displayPhone)
            .putString(KEY_TOKEN, "")
            .apply()
    }

    fun logout(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .clear()
            .apply()
    }
}
