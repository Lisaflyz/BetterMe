package com.betterme.app

import android.net.Uri
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.recyclerview.widget.RecyclerView
import com.betterme.app.databinding.ItemMediaCellBinding

/** 相册里的一个媒体项（照片或视频）。 */
data class MediaItem(
    val uri: Uri,
    val id: Long,
    val kind: Kind,
    val dateAdded: Long,
    val durationMs: Long = 0L
) {
    enum class Kind { PHOTO, VIDEO }
}

/**
 * 相册网格 Adapter：负责缩略图加载（MediaThumbLoader）与多选角标。
 */
class AlbumAdapter(
    private val cellSizePx: Int,
    private val onItemClick: (MediaItem) -> Unit
) : RecyclerView.Adapter<AlbumAdapter.VH>() {

    /** 返回某个 item 当前被选中的序号；未选中返回 -1。 */
    var selectionOrder: (MediaItem) -> Int = { -1 }

    private val items = mutableListOf<MediaItem>()
    private val loader = MediaThumbLoader()

    fun submit(list: List<MediaItem>) {
        items.clear()
        items.addAll(list)
        notifyDataSetChanged()
    }

    override fun getItemCount(): Int = items.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val binding = ItemMediaCellBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return VH(binding)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = items[position]
        holder.binding.cellRoot.layoutParams = FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, cellSizePx
        )
        val order = selectionOrder(item)
        holder.binding.tvBadge.visibility =
            if (order >= 0) android.view.View.VISIBLE else android.view.View.GONE
        if (order >= 0) holder.binding.tvBadge.text = (order + 1).toString()

        if (item.kind == MediaItem.Kind.VIDEO) {
            holder.binding.videoTag.visibility = android.view.View.VISIBLE
            holder.binding.tvDuration.text = formatDuration(item.durationMs)
        } else {
            holder.binding.videoTag.visibility = android.view.View.GONE
        }

        holder.binding.cellRoot.setOnClickListener { onItemClick(item) }
        loader.load(item, holder.binding.ivThumb)
    }

    private fun formatDuration(ms: Long): String {
        val totalSec = ms / 1000
        val h = totalSec / 3600
        val m = (totalSec % 3600) / 60
        val s = totalSec % 60
        return if (h > 0) {
            String.format("%d:%02d:%02d", h, m, s)
        } else {
            String.format("%02d:%02d", m, s)
        }
    }

    class VH(val binding: ItemMediaCellBinding) :
        RecyclerView.ViewHolder(binding.root)
}
