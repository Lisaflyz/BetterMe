package com.betterme.app.ui

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.betterme.app.R
import com.betterme.app.Session
import com.betterme.app.databinding.ActivityPhoneLoginBinding
import com.betterme.app.network.ApiClient
import com.betterme.app.network.LoginRequest
import com.betterme.app.network.SendCodeRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * 手机号登录页（参考 手机登录.jpg）：+86 手机号 + 验证码 + 立即登录。
 *
 * 已接后端接口：
 *   POST /api/v1/auth/send-code   （发送验证码，见 backend/main.py）
 *   POST /api/v1/auth/login       （校验验证码 → 返回 JWT + 用户信息）
 * 后端地址在 app/build.gradle.kts 的 BuildConfig.API_BASE_URL 配置。
 */
class PhoneLoginActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPhoneLoginBinding
    private var countdownJob: kotlinx.coroutines.Job? = null
    private var sending = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPhoneLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnBack.setOnClickListener { finish() }
        binding.btnGetCode.setOnClickListener { sendCode() }

        val watcher = object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) = updateLoginButton()
        }
        binding.etPhone.addTextChangedListener(watcher)
        binding.etCode.addTextChangedListener(watcher)

        binding.btnLogin.setOnClickListener { doLogin() }
        updateLoginButton()
    }

    private fun updateLoginButton() {
        val enabled = phoneValid() && binding.etCode.text?.isNotEmpty() == true
        binding.btnLogin.isEnabled = enabled
        binding.btnLogin.isClickable = enabled
        binding.btnLogin.background = ContextCompat.getDrawable(
            this,
            if (enabled) R.drawable.bg_pill_primary else R.drawable.bg_pill_disabled
        )
    }

    private fun phoneValid(): Boolean {
        val phone = binding.etPhone.text?.toString().orEmpty()
        return phone.length == 11 && phone.startsWith("1")
    }

    private fun sendCode() {
        if (!phoneValid()) {
            Toast.makeText(this, R.string.phone_invalid, Toast.LENGTH_SHORT).show()
            return
        }
        if (sending) return
        sending = true
        binding.btnGetCode.isEnabled = false
        binding.btnGetCode.setTextColor(ContextCompat.getColor(this, R.color.text_tertiary))
        binding.btnGetCode.text = "发送中…"

        val phone = binding.etPhone.text.toString()
        lifecycleScope.launch {
            runCatching {
                withContext(Dispatchers.IO) {
                    ApiClient.service.sendCode(SendCodeRequest(phone))
                }
            }.onSuccess { resp ->
                if (resp.code == 0) {
                    // 开发模式：后端会回传 debugCode，方便没接短信时测试
                    resp.data?.debugCode?.takeIf { it.isNotBlank() }?.let {
                        Toast.makeText(
                            this@PhoneLoginActivity,
                            "验证码(测试环境): $it",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                    startCountdown()
                } else {
                    Toast.makeText(this@PhoneLoginActivity, resp.message, Toast.LENGTH_SHORT).show()
                    resetCodeButton()
                }
            }.onFailure { e ->
                Toast.makeText(
                    this@PhoneLoginActivity,
                    "发送失败：${e.message ?: "网络错误"}",
                    Toast.LENGTH_SHORT
                ).show()
                resetCodeButton()
            }
            sending = false
        }
    }

    private fun resetCodeButton() {
        binding.btnGetCode.isEnabled = true
        binding.btnGetCode.setTextColor(ContextCompat.getColor(this, R.color.accent))
        binding.btnGetCode.text = getString(R.string.phone_get_code)
    }

    private fun startCountdown() {
        countdownJob?.cancel()
        binding.btnGetCode.isEnabled = false
        binding.btnGetCode.setTextColor(ContextCompat.getColor(this, R.color.text_tertiary))
        countdownJob = lifecycleScope.launch {
            var remain = 60
            while (remain > 0) {
                binding.btnGetCode.text = getString(R.string.phone_resend, remain)
                delay(1000)
                remain--
            }
            resetCodeButton()
        }
    }

    private fun doLogin() {
        val phone = binding.etPhone.text?.toString().orEmpty()
        val code = binding.etCode.text?.toString().orEmpty()
        if (!phoneValid()) {
            Toast.makeText(this, R.string.phone_invalid, Toast.LENGTH_SHORT).show()
            return
        }
        if (code.isEmpty()) {
            Toast.makeText(this, R.string.phone_code_empty, Toast.LENGTH_SHORT).show()
            return
        }
        binding.btnLogin.isEnabled = false
        binding.btnLogin.text = "登录中…"

        lifecycleScope.launch {
            runCatching {
                withContext(Dispatchers.IO) {
                    ApiClient.service.login(LoginRequest(phone, code))
                }
            }.onSuccess { resp ->
                if (resp.code == 0 && resp.data != null) {
                    val data = resp.data
                    Session.loginWithToken(
                        this@PhoneLoginActivity,
                        data.user.phone,
                        data.token,
                        data.user.id
                    )
                    Toast.makeText(
                        this@PhoneLoginActivity,
                        R.string.phone_login_success,
                        Toast.LENGTH_SHORT
                    ).show()
                    setResult(RESULT_OK)
                    finish()
                } else {
                    Toast.makeText(
                        this@PhoneLoginActivity,
                        resp.message.ifBlank { "登录失败" },
                        Toast.LENGTH_SHORT
                    ).show()
                    resetLoginButton()
                }
            }.onFailure { e ->
                Toast.makeText(
                    this@PhoneLoginActivity,
                    "登录失败：${e.message ?: "网络错误"}",
                    Toast.LENGTH_SHORT
                ).show()
                resetLoginButton()
            }
        }
    }

    private fun resetLoginButton() {
        binding.btnLogin.text = getString(R.string.phone_login_btn)
        updateLoginButton()
    }

    override fun onDestroy() {
        super.onDestroy()
        countdownJob?.cancel()
    }
}
