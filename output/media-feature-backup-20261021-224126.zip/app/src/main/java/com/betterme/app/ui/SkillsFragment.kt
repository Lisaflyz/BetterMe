package com.betterme.app.ui

import androidx.fragment.app.Fragment
import com.betterme.app.R

/** 技能页，后续接入技能与练习进度。 */
class SkillsFragment : Fragment(R.layout.fragment_skills)
