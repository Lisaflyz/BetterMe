package com.betterme.app.network

import retrofit2.http.Body
import retrofit2.http.POST

interface ApiService {

    /** 发送短信验证码 */
    @POST("api/v1/auth/send-code")
    suspend fun sendCode(@Body body: SendCodeRequest): ApiResponse<SendCodeData>

    /** 手机号 + 验证码登录 */
    @POST("api/v1/auth/login")
    suspend fun login(@Body body: LoginRequest): ApiResponse<LoginData>
}

// ---------- DTO ----------
data class SendCodeRequest(val phone: String)

data class SendCodeData(val debugCode: String? = null)

data class LoginRequest(val phone: String, val code: String)

data class LoginData(
    val token: String,
    val user: UserData
)

data class UserData(
    val id: Long,
    val phone: String,
    val nickname: String? = null
)

/** 与后端约定统一的返回结构：{code:0, message:"ok", data:{...}} */
data class ApiResponse<T>(
    val code: Int = -1,
    val message: String = "",
    val data: T? = null
)
