package com.betterme.app.ui

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.betterme.app.R
import com.betterme.app.Session
import com.betterme.app.WechatManager
import com.betterme.app.databinding.FragmentLoginBinding
import com.betterme.app.databinding.FragmentMeProfileBinding
import com.betterme.app.databinding.FragmentProfileBinding

/**
 * “我”Tab：未登录 → 展示登录页（参考 登录.jpg）；
 * 点击「手机号登录」→ PhoneLoginActivity（参考 手机登录.jpg）。
 * 登录成功（本地示例）后展示已登录占位主页。
 */
class ProfileFragment : Fragment() {

    private var _binding: FragmentProfileBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentProfileBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        render()
    }

    /** 每次回到该 Tab（onResume）都重新渲染，保证登录/退出后立即刷新。 */
    override fun onResume() {
        super.onResume()
        render()
    }

    private fun render() {
        binding.container.removeAllViews()
        val context = requireContext()
        if (Session.isLoggedIn(context)) {
            showLoggedIn()
        } else {
            showLogin()
        }
    }

    private fun showLogin() {
        val loginBinding = FragmentLoginBinding.inflate(layoutInflater)
        binding.container.addView(loginBinding.root)

        loginBinding.btnWechat.setOnClickListener {
            // 拉起微信授权；结果在 com.betterme.app.wxapi.WXEntryActivity 回调
            WechatManager.login(requireContext())
        }
        loginBinding.btnPhone.setOnClickListener {
            startActivity(Intent(requireContext(), PhoneLoginActivity::class.java))
        }
        loginBinding.btnOther.setOnClickListener {
            Toast.makeText(requireContext(), R.string.login_other_todo, Toast.LENGTH_SHORT).show()
        }
        loginBinding.tvAgreement.setOnClickListener {
            Toast.makeText(requireContext(), R.string.login_agreement_todo, Toast.LENGTH_SHORT).show()
        }
    }

    private fun showLoggedIn() {
        val meBinding = FragmentMeProfileBinding.inflate(layoutInflater)
        binding.container.addView(meBinding.root)

        val phone = Session.getPhone(requireContext())
        meBinding.tvAvatar.text = if (phone.isNotEmpty()) phone.takeLast(4) else "BM"
        meBinding.tvLoggedPhone.text = getString(R.string.me_logged_phone, phone)
        meBinding.btnLogout.setOnClickListener {
            Session.logout(requireContext())
            render()
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
