package com.betterme.app

import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView

/** Reuse selected thumbnails when adding, removing or reordering items. */
class AlbumSelectedAdapter(private val onRemove: (MediaItem) -> Unit) :
    ListAdapter<AlbumCell, AlbumSelectedAdapter.VH>(AlbumCellDiff) {
    private val loader = MediaThumbLoader()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val context = parent.context
        fun dp(value: Int) = (value * context.resources.displayMetrics.density).toInt()
        val tile = FrameLayout(context).apply {
            layoutParams = RecyclerView.LayoutParams(dp(74), dp(74)).apply { marginEnd = dp(14) }
            clipChildren = false
            clipToPadding = false
        }
        val thumb = ImageView(context).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            setBackgroundResource(R.drawable.bg_album_selected_thumb)
            clipToOutline = true
        }
        tile.addView(thumb, FrameLayout.LayoutParams(-1, -1))
        // Keep the 6dp glyph and overflowing round badge, with a larger touch target.
        val remove = FrameLayout(context).apply {
            isFocusable = true
            clipChildren = false
            clipToPadding = false
        }
        val badge = FrameLayout(context).apply {
            setBackgroundResource(R.drawable.bg_album_remove)
            importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO_HIDE_DESCENDANTS
        }
        badge.addView(ImageView(context).apply { setImageResource(R.drawable.ic_album_remove) },
            FrameLayout.LayoutParams(dp(6), dp(6), Gravity.CENTER))
        remove.addView(badge, FrameLayout.LayoutParams(dp(18), dp(18), Gravity.TOP or Gravity.END).apply {
            topMargin = -dp(6)
            marginEnd = -dp(6)
        })
        tile.addView(remove, FrameLayout.LayoutParams(dp(48), dp(48), Gravity.TOP or Gravity.END))
        return VH(tile, thumb, remove).also { holder ->
            remove.setOnClickListener {
                val position = holder.bindingAdapterPosition
                if (position != RecyclerView.NO_POSITION) onRemove(getItem(position).media)
            }
        }
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val cell = getItem(position)
        bindOrder(holder, cell)
        loader.load(cell.media, holder.thumb)
    }

    override fun onBindViewHolder(holder: VH, position: Int, payloads: MutableList<Any>) {
        if (payloads.isNotEmpty() && payloads.all { it === AlbumSelectionChanged }) {
            bindOrder(holder, getItem(position))
        } else {
            onBindViewHolder(holder, position)
        }
    }

    private fun bindOrder(holder: VH, cell: AlbumCell) {
        holder.remove.contentDescription = "移除第${cell.selectionOrder + 1}项"
    }

    override fun onViewRecycled(holder: VH) {
        holder.thumb.tag = null
        holder.thumb.setImageDrawable(null)
        super.onViewRecycled(holder)
    }

    class VH(root: FrameLayout, val thumb: ImageView, val remove: FrameLayout) : RecyclerView.ViewHolder(root)
}
